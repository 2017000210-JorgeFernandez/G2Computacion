/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora_13_jorgefernandez;

/**
 *
 * @author LABORATORIO
 */
public class Calculadora_13_JorgeFernandez {
  
 
 

    
    public static void main(String[] args) {
        Calculadora v1= new Calculadora();
        v1.setVisible(true);

       
       
    }
    
}
